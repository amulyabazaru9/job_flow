'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { auth } from '@/lib/api';
import type { User } from '@/types';

/**
 * Loads the current user from the JWT in localStorage. Redirects to /login when
 * `redirect` is true and no valid session exists.
 */
export function useAuth(redirect = true) {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const router = useRouter();

  useEffect(() => {
    const token = localStorage.getItem('jobflow_token');
    if (!token) {
      setLoading(false);
      if (redirect) router.push('/login');
      return;
    }

    auth
      .me()
      .then(setUser)
      .catch(() => {
        if (redirect) router.push('/login');
      })
      .finally(() => setLoading(false));
  }, [redirect, router]);

  const logout = () => {
    localStorage.removeItem('jobflow_token');
    router.push('/login');
  };

  return { user, loading, logout };
}
