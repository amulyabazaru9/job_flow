'use client';

import { useState } from 'react';
import { Search, Loader2, MapPin, ExternalLink, Plus } from 'lucide-react';
import { jobs as jobApi } from '@/lib/api';
import type { Job } from '@/types';

const PRESETS = ['Java Developer', 'Full Stack Developer', 'Python Developer'];

export function JobSearchPanel({ onApply }: { onApply: (jobId: string) => void }) {
  const [query, setQuery] = useState('');
  const [remote, setRemote] = useState(false);
  const [contract, setContract] = useState(false);
  const [results, setResults] = useState<Job[]>([]);
  const [loading, setLoading] = useState(false);

  async function run(q: string) {
    if (!q.trim()) return;
    setLoading(true);
    try {
      setResults(await jobApi.search(q, { remote, contract }));
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="rounded-lg border border-line bg-surface p-5">
      <h2 className="text-sm font-semibold">Find roles</h2>

      <div className="mt-4 flex gap-2">
        <div className="flex flex-1 items-center gap-2 rounded-md border border-line bg-ink px-3">
          <Search size={16} className="text-muted" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && run(query)}
            placeholder="Java Developer, Remote…"
            className="w-full bg-transparent py-2.5 text-sm outline-none placeholder:text-muted"
          />
        </div>
        <button
          onClick={() => run(query)}
          className="rounded-md bg-accent px-4 text-sm font-medium text-ink transition hover:bg-accent/90"
        >
          Search
        </button>
      </div>

      <div className="mt-3 flex flex-wrap items-center gap-2">
        {PRESETS.map((p) => (
          <button
            key={p}
            onClick={() => {
              setQuery(p);
              run(p);
            }}
            className="rounded-full border border-line px-3 py-1 font-mono text-[11px] text-muted transition hover:border-accent hover:text-white"
          >
            {p}
          </button>
        ))}
        <label className="ml-auto flex items-center gap-1.5 text-xs text-muted">
          <input type="checkbox" checked={remote} onChange={(e) => setRemote(e.target.checked)} />
          Remote
        </label>
        <label className="flex items-center gap-1.5 text-xs text-muted">
          <input
            type="checkbox"
            checked={contract}
            onChange={(e) => setContract(e.target.checked)}
          />
          Contract
        </label>
      </div>

      <div className="mt-4 max-h-[420px] space-y-2 overflow-y-auto pr-1">
        {loading && (
          <div className="flex items-center justify-center py-10 text-muted">
            <Loader2 className="animate-spin" />
          </div>
        )}
        {!loading && results.length === 0 && (
          <p className="py-10 text-center text-sm text-muted">
            Search a role to see openings from public job boards.
          </p>
        )}
        {results.map((job) => (
          <div key={job._id} className="rounded-md border border-line bg-ink p-3">
            <div className="flex items-start justify-between gap-3">
              <div className="min-w-0">
                <p className="truncate text-sm font-medium">{job.title}</p>
                <p className="truncate text-xs text-muted">{job.company}</p>
              </div>
              <span className="eyebrow shrink-0">{job.source}</span>
            </div>
            <div className="mt-2 flex items-center gap-3 text-xs text-muted">
              {job.location && (
                <span className="flex items-center gap-1">
                  <MapPin size={12} /> {job.location}
                </span>
              )}
              {job.remote && <span className="text-accent">remote</span>}
              {job.contract && <span className="text-amber-400">contract</span>}
            </div>
            <div className="mt-3 flex items-center gap-2">
              <button
                onClick={() => onApply(job._id)}
                className="inline-flex items-center gap-1.5 rounded bg-accent-soft px-3 py-1.5 text-xs font-medium text-accent transition hover:bg-accent hover:text-ink"
              >
                <Plus size={13} /> Draft application
              </button>
              <a
                href={job.sourceUrl}
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-1 text-xs text-muted hover:text-white"
              >
                View posting <ExternalLink size={12} />
              </a>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
