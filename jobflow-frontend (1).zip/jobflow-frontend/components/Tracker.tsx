'use client';

import { Eye } from 'lucide-react';
import { StatusBadge } from './StatusBadge';
import { applications as appApi } from '@/lib/api';
import type { Application, ApplicationStatus } from '@/types';

const STATUSES: ApplicationStatus[] = ['draft', 'applied', 'interview', 'rejected', 'offer'];

export function Tracker({
  items,
  onReview,
  onChange,
}: {
  items: Application[];
  onReview: (app: Application) => void;
  onChange: () => void;
}) {
  async function setStatus(id: string, status: ApplicationStatus) {
    await appApi.updateStatus(id, status);
    onChange();
  }

  return (
    <div className="rounded-lg border border-line bg-surface">
      <div className="flex items-center justify-between border-b border-line px-5 py-4">
        <h2 className="text-sm font-semibold">Application tracker</h2>
        <span className="font-mono text-xs text-muted">{items.length} total</span>
      </div>

      {items.length === 0 ? (
        <p className="px-5 py-12 text-center text-sm text-muted">
          No applications yet. Draft one from a job search result.
        </p>
      ) : (
        <ul className="divide-y divide-line">
          {items.map((app) => (
            <li key={app._id} className="flex items-center gap-4 px-5 py-3">
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-medium">{app.job?.title}</p>
                <p className="truncate text-xs text-muted">{app.job?.company}</p>
              </div>

              <StatusBadge status={app.status} />

              <select
                value={app.status}
                onChange={(e) => setStatus(app._id, e.target.value as ApplicationStatus)}
                className="rounded-md border border-line bg-ink px-2 py-1 font-mono text-xs text-muted outline-none focus:border-accent"
              >
                {STATUSES.map((s) => (
                  <option key={s} value={s}>
                    {s}
                  </option>
                ))}
              </select>

              <button
                onClick={() => onReview(app)}
                className="inline-flex items-center gap-1.5 rounded-md border border-line px-3 py-1.5 text-xs transition hover:border-accent"
              >
                <Eye size={13} /> Review
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
