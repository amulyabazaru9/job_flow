'use client';

import { useRef, useState } from 'react';
import { Upload, FileText, Trash2, Loader2 } from 'lucide-react';
import { resumes as resumeApi } from '@/lib/api';
import type { Resume } from '@/types';

export function ResumePanel({
  items,
  onChange,
}: {
  items: Resume[];
  onChange: () => void;
}) {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);

  async function handleFile(file?: File) {
    if (!file) return;
    setError('');
    setBusy(true);
    try {
      await resumeApi.upload(file);
      onChange();
    } catch (e: any) {
      setError(e?.response?.data?.error || 'Upload failed');
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="rounded-lg border border-line bg-surface p-5">
      <div className="flex items-center justify-between">
        <h2 className="text-sm font-semibold">Resumes</h2>
        <span className="font-mono text-xs text-muted">{items.length} on file</span>
      </div>

      <button
        onClick={() => inputRef.current?.click()}
        disabled={busy}
        className="mt-4 flex w-full items-center justify-center gap-2 rounded-md border border-dashed border-line py-6 text-sm text-muted transition hover:border-accent hover:text-white disabled:opacity-50"
      >
        {busy ? <Loader2 size={18} className="animate-spin" /> : <Upload size={18} />}
        {busy ? 'Parsing…' : 'Upload PDF or DOCX'}
      </button>
      <input
        ref={inputRef}
        type="file"
        accept=".pdf,.docx,application/pdf,application/vnd.openxmlformats-officedocument.wordprocessingml.document"
        className="hidden"
        onChange={(e) => handleFile(e.target.files?.[0])}
      />

      {error && <p className="mt-2 text-xs text-red-400">{error}</p>}

      <ul className="mt-4 space-y-2">
        {items.map((r) => (
          <li
            key={r._id}
            className="flex items-center gap-3 rounded-md border border-line bg-ink px-3 py-2"
          >
            <FileText size={16} className="shrink-0 text-accent" />
            <div className="min-w-0 flex-1">
              <p className="truncate text-sm">{r.originalName}</p>
              <p className="font-mono text-[11px] text-muted">
                {r.parsed?.skills?.slice(0, 4).join(' · ') || 'no skills parsed'}
              </p>
            </div>
            {r.isPrimary && <span className="eyebrow">primary</span>}
            <button
              onClick={async () => {
                await resumeApi.remove(r._id);
                onChange();
              }}
              className="text-muted transition hover:text-red-400"
              aria-label="Delete resume"
            >
              <Trash2 size={15} />
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}
