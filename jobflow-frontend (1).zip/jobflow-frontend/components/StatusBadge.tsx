import type { ApplicationStatus } from '@/types';

const STYLES: Record<ApplicationStatus, string> = {
  draft: 'bg-line text-muted',
  applied: 'bg-accent-soft text-accent',
  interview: 'bg-amber-500/15 text-amber-400',
  rejected: 'bg-red-500/15 text-red-400',
  offer: 'bg-emerald-500/15 text-emerald-400',
};

export function StatusBadge({ status }: { status: ApplicationStatus }) {
  return (
    <span
      className={`inline-flex items-center rounded px-2 py-0.5 font-mono text-[11px] uppercase tracking-wider ${STYLES[status]}`}
    >
      {status}
    </span>
  );
}
