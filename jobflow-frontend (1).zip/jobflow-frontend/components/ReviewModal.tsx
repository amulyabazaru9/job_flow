'use client';

import { useState } from 'react';
import { X, Send, Loader2, ShieldCheck } from 'lucide-react';
import { applications as appApi } from '@/lib/api';
import type { Application } from '@/types';

/**
 * The review gate. The AI-drafted email is fully editable here, and nothing is
 * sent until the user types a recipient and clicks Approve & send.
 */
export function ReviewModal({
  application,
  onClose,
  onSent,
}: {
  application: Application;
  onClose: () => void;
  onSent: () => void;
}) {
  const [subject, setSubject] = useState(application.generatedEmail.subject);
  const [body, setBody] = useState(application.generatedEmail.body);
  const [recipient, setRecipient] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  async function send() {
    if (!recipient.trim()) {
      setError('Add a recipient email before sending.');
      return;
    }
    setBusy(true);
    setError('');
    try {
      await appApi.updateEmail(application._id, subject, body);
      await appApi.approveSend(application._id, recipient.trim());
      onSent();
    } catch (e: any) {
      setError(e?.response?.data?.error || 'Could not send. Check your Google connection.');
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4">
      <div className="flex max-h-[90vh] w-full max-w-2xl flex-col rounded-lg border border-line bg-surface">
        <header className="flex items-center justify-between border-b border-line px-5 py-4">
          <div>
            <p className="eyebrow">Review before sending</p>
            <h2 className="mt-1 text-sm font-semibold">
              {application.job.title} · {application.job.company}
            </h2>
          </div>
          <button onClick={onClose} className="text-muted hover:text-white">
            <X size={18} />
          </button>
        </header>

        <div className="flex-1 space-y-4 overflow-y-auto p-5">
          <label className="block">
            <span className="eyebrow">Recipient</span>
            <input
              value={recipient}
              onChange={(e) => setRecipient(e.target.value)}
              placeholder="hiring@company.com"
              className="mt-1.5 w-full rounded-md border border-line bg-ink px-3 py-2 text-sm outline-none focus:border-accent"
            />
          </label>

          <label className="block">
            <span className="eyebrow">Subject</span>
            <input
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
              className="mt-1.5 w-full rounded-md border border-line bg-ink px-3 py-2 text-sm outline-none focus:border-accent"
            />
          </label>

          <label className="block">
            <span className="eyebrow">Message</span>
            <textarea
              value={body}
              onChange={(e) => setBody(e.target.value)}
              rows={12}
              className="mt-1.5 w-full resize-none rounded-md border border-line bg-ink px-3 py-2 text-sm leading-relaxed outline-none focus:border-accent"
            />
          </label>

          <p className="flex items-center gap-2 text-xs text-muted">
            <ShieldCheck size={14} className="text-accent" />
            This email sends from your own Gmail. It goes out only when you click below.
          </p>
          {error && <p className="text-xs text-red-400">{error}</p>}
        </div>

        <footer className="flex items-center justify-end gap-3 border-t border-line px-5 py-4">
          <button onClick={onClose} className="text-sm text-muted hover:text-white">
            Cancel
          </button>
          <button
            onClick={send}
            disabled={busy}
            className="inline-flex items-center gap-2 rounded-md bg-accent px-4 py-2 text-sm font-medium text-ink transition hover:bg-accent/90 disabled:opacity-50"
          >
            {busy ? <Loader2 size={15} className="animate-spin" /> : <Send size={15} />}
            Approve &amp; send
          </button>
        </footer>
      </div>
    </div>
  );
}
