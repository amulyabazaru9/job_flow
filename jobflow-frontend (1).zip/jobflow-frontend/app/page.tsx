import Link from 'next/link';
import { ArrowRight, FileText, Search, Sparkles, CheckCircle2 } from 'lucide-react';

const steps = [
  { icon: FileText, label: 'Parse', text: 'Upload a resume. We extract your skills and experience automatically.' },
  { icon: Search, label: 'Find', text: 'Search public job boards by role, location, and contract type.' },
  { icon: Sparkles, label: 'Draft', text: 'Claude writes a tailored application email grounded in your real resume.' },
  { icon: CheckCircle2, label: 'Approve', text: 'You review and approve every email before a single one is sent.' },
];

export default function Home() {
  return (
    <main className="min-h-screen">
      {/* Hero */}
      <section className="mx-auto max-w-6xl px-6 pt-28 pb-20">
        <p className="eyebrow mb-6">Job application control room</p>
        <h1 className="max-w-3xl text-5xl font-semibold leading-[1.05] tracking-tight md:text-6xl">
          Every application,
          <br />
          <span className="text-accent">on the record.</span>
        </h1>
        <p className="mt-6 max-w-xl text-lg text-muted">
          JobFlow AI handles the busywork of a job search — parsing, searching, and drafting — while
          keeping you in command of what actually gets sent.
        </p>
        <div className="mt-10 flex items-center gap-4">
          <Link
            href="/login"
            className="group inline-flex items-center gap-2 rounded-md bg-accent px-5 py-3 font-medium text-ink transition hover:bg-accent/90"
          >
            Open the dashboard
            <ArrowRight size={18} className="transition group-hover:translate-x-0.5" />
          </Link>
          <a href="#how" className="text-sm text-muted hover:text-white">
            How it works
          </a>
        </div>
      </section>

      {/* Process — a real sequence, so numbered markers earn their place */}
      <section id="how" className="border-t border-line">
        <div className="mx-auto grid max-w-6xl gap-px bg-line md:grid-cols-4">
          {steps.map((s, i) => (
            <div key={s.label} className="bg-ink p-8">
              <div className="flex items-center justify-between">
                <s.icon size={20} className="text-accent" />
                <span className="font-mono text-xs text-muted">0{i + 1}</span>
              </div>
              <h3 className="mt-6 text-sm font-semibold uppercase tracking-wide">{s.label}</h3>
              <p className="mt-2 text-sm leading-relaxed text-muted">{s.text}</p>
            </div>
          ))}
        </div>
      </section>

      <footer className="mx-auto max-w-6xl px-6 py-10 text-sm text-muted">
        Applications are never sent without your explicit approval. JobFlow AI respects every
        platform&apos;s terms and never bypasses logins or CAPTCHAs.
      </footer>
    </main>
  );
}
