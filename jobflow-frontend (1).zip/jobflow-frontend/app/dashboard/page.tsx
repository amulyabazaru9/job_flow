'use client';

import { useCallback, useEffect, useState } from 'react';
import { LogOut, Loader2 } from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';
import { resumes as resumeApi, applications as appApi } from '@/lib/api';
import { ResumePanel } from '@/components/ResumePanel';
import { JobSearchPanel } from '@/components/JobSearchPanel';
import { Tracker } from '@/components/Tracker';
import { ReviewModal } from '@/components/ReviewModal';
import type { Application, Resume } from '@/types';

export default function Dashboard() {
  const { user, loading, logout } = useAuth();
  const [resumeList, setResumeList] = useState<Resume[]>([]);
  const [appList, setAppList] = useState<Application[]>([]);
  const [reviewing, setReviewing] = useState<Application | null>(null);
  const [drafting, setDrafting] = useState(false);

  const refreshResumes = useCallback(() => {
    resumeApi.list().then(setResumeList).catch(() => {});
  }, []);
  const refreshApps = useCallback(() => {
    appApi.list().then(setAppList).catch(() => {});
  }, []);

  useEffect(() => {
    if (user) {
      refreshResumes();
      refreshApps();
    }
  }, [user, refreshResumes, refreshApps]);

  async function draftApplication(jobId: string) {
    setDrafting(true);
    try {
      const app = await appApi.create(jobId);
      await refreshApps();
      setReviewing(app);
    } finally {
      setDrafting(false);
    }
  }

  if (loading) {
    return (
      <main className="flex min-h-screen items-center justify-center">
        <Loader2 className="animate-spin text-muted" />
      </main>
    );
  }

  return (
    <main className="min-h-screen">
      <header className="border-b border-line">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-4">
          <div className="flex items-center gap-3">
            <span className="font-mono text-sm font-semibold tracking-tight text-accent">
              JobFlow<span className="text-white">AI</span>
            </span>
          </div>
          <div className="flex items-center gap-4">
            <span className="text-sm text-muted">{user?.email}</span>
            <button
              onClick={logout}
              className="flex items-center gap-1.5 text-sm text-muted transition hover:text-white"
            >
              <LogOut size={15} /> Sign out
            </button>
          </div>
        </div>
      </header>

      <div className="mx-auto max-w-6xl px-6 py-8">
        <p className="eyebrow">Control room</p>
        <h1 className="mt-1 text-2xl font-semibold tracking-tight">
          Welcome back, {user?.name?.split(' ')[0]}
        </h1>

        <div className="mt-8 grid gap-6 lg:grid-cols-[1fr_1.2fr]">
          <div className="space-y-6">
            <ResumePanel items={resumeList} onChange={refreshResumes} />
            <JobSearchPanel onApply={draftApplication} />
          </div>
          <Tracker items={appList} onReview={setReviewing} onChange={refreshApps} />
        </div>
      </div>

      {drafting && (
        <div className="fixed inset-0 z-40 flex items-center justify-center bg-black/60">
          <div className="flex items-center gap-3 rounded-lg border border-line bg-surface px-6 py-4 text-sm">
            <Loader2 className="animate-spin text-accent" />
            Drafting your application with AI…
          </div>
        </div>
      )}

      {reviewing && (
        <ReviewModal
          application={reviewing}
          onClose={() => setReviewing(null)}
          onSent={() => {
            setReviewing(null);
            refreshApps();
          }}
        />
      )}
    </main>
  );
}
