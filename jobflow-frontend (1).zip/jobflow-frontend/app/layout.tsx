import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'JobFlow AI — application control room',
  description:
    'Track your job search end to end: parse resumes, find roles, draft applications with AI, and review every send before it goes out.',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="font-sans antialiased">{children}</body>
    </html>
  );
}
