export interface User {
  _id: string;
  email: string;
  name: string;
  avatar?: string;
  profile?: {
    title?: string;
    skills?: string[];
    yearsExperience?: number;
    location?: string;
  };
  preferences?: {
    keywords?: string[];
    remoteOnly?: boolean;
    contractOnly?: boolean;
  };
}

export interface Resume {
  _id: string;
  originalName: string;
  mimeType: string;
  sizeBytes: number;
  isPrimary: boolean;
  parsed?: {
    email?: string;
    phone?: string;
    skills?: string[];
    yearsExperience?: number;
  };
  createdAt: string;
}

export interface Job {
  _id: string;
  source: string;
  title: string;
  company: string;
  location?: string;
  remote: boolean;
  contract: boolean;
  description?: string;
  salary?: string;
  sourceUrl: string;
  postedAt?: string;
}

export type ApplicationStatus = 'draft' | 'applied' | 'interview' | 'rejected' | 'offer';

export interface Application {
  _id: string;
  job: Job;
  status: ApplicationStatus;
  generatedEmail: {
    subject: string;
    body: string;
    approved: boolean;
  };
  sentAt?: string;
  createdAt: string;
  updatedAt: string;
}
