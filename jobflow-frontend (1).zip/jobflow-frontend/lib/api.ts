import axios from 'axios';
import type { Application, ApplicationStatus, Job, Resume, User } from '@/types';

const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:5000/api';

const api = axios.create({ baseURL: API_URL });

// Attach JWT from localStorage to every request.
api.interceptors.request.use((cfg) => {
  if (typeof window !== 'undefined') {
    const token = localStorage.getItem('jobflow_token');
    if (token) cfg.headers.Authorization = `Bearer ${token}`;
  }
  return cfg;
});

// On 401, clear token and bounce to login.
api.interceptors.response.use(
  (res) => res,
  (err) => {
    if (err.response?.status === 401 && typeof window !== 'undefined') {
      localStorage.removeItem('jobflow_token');
      if (!window.location.pathname.startsWith('/login')) {
        window.location.href = '/login';
      }
    }
    return Promise.reject(err);
  }
);

export const auth = {
  loginUrl: () => `${API_URL}/auth/google`,
  me: () => api.get<{ user: User }>('/auth/me').then((r) => r.data.user),
};

export const resumes = {
  list: () => api.get<{ resumes: Resume[] }>('/resumes').then((r) => r.data.resumes),
  upload: (file: File) => {
    const fd = new FormData();
    fd.append('resume', file);
    return api
      .post<{ resume: Resume }>('/resumes', fd, {
        headers: { 'Content-Type': 'multipart/form-data' },
      })
      .then((r) => r.data.resume);
  },
  remove: (id: string) => api.delete(`/resumes/${id}`).then((r) => r.data),
};

export const jobs = {
  search: (q: string, opts: { remote?: boolean; contract?: boolean } = {}) =>
    api
      .get<{ jobs: Job[] }>('/jobs/search', {
        params: { q, remote: opts.remote, contract: opts.contract },
      })
      .then((r) => r.data.jobs),
};

export const applications = {
  list: () =>
    api.get<{ applications: Application[] }>('/applications').then((r) => r.data.applications),
  create: (jobId: string, resumeId?: string) =>
    api
      .post<{ application: Application }>('/applications', { jobId, resumeId })
      .then((r) => r.data.application),
  updateEmail: (id: string, subject: string, body: string) =>
    api
      .patch<{ application: Application }>(`/applications/${id}/email`, { subject, body })
      .then((r) => r.data.application),
  approveSend: (id: string, recipientEmail: string) =>
    api
      .post<{ application: Application }>(`/applications/${id}/approve-send`, { recipientEmail })
      .then((r) => r.data.application),
  updateStatus: (id: string, status: ApplicationStatus) =>
    api
      .patch<{ application: Application }>(`/applications/${id}/status`, { status })
      .then((r) => r.data.application),
};

export default api;
